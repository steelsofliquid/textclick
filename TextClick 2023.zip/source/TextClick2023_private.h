/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef TEXTCLICK2023_PRIVATE_H
#define TEXTCLICK2023_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"8.0.1.477"
#define VER_MAJOR	8
#define VER_MINOR	0
#define VER_RELEASE	1
#define VER_BUILD	477
#define COMPANY_NAME	"Nathan Renaud (SteelsOfLiquid)"
#define FILE_VERSION	"8.0.1.477"
#define FILE_DESCRIPTION	"TextClick 2023"
#define INTERNAL_NAME	""
#define LEGAL_COPYRIGHT	"TextClick 2023 is not copyright. It was created in 2023 by Nathan Renaud."
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	""
#define PRODUCT_NAME	"TextClick 2023 Text Editor (32-bit)"
#define PRODUCT_VERSION	"8.0.1.477"

#endif /*TEXTCLICK2023_PRIVATE_H*/
